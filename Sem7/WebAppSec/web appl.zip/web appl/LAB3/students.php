<?php

header("Content-Type: application/json");

$students = [

[
"registerNumber"=>"23034",
"name"=>"Vedica",
"department"=>"CYS",
"semester"=>6,
"cgpa"=>9.02
],

[
"registerNumber"=>"23045",
"name"=>"Soffia",
"department"=>"CYS",
"semester"=>6,
"cgpa"=>8.72
],

[
"registerNumber"=>"23052",
"name"=>"Vedha",
"department"=>"CYS",
"semester"=>6,
"cgpa"=>8.75
],

[
"registerNumber"=>"23002",
"name"=>"Anagha",
"department"=>"CYS",
"semester"=>6,
"cgpa"=>9.16
],

[
"registerNumber"=>"23334",
"name"=>"Renny",
"department"=>"AI",
"semester"=>6,
"cgpa"=>9.57
]

];

echo json_encode($students);

?>